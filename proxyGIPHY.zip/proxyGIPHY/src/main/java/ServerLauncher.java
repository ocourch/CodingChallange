package main.java;

import java.io.IOException;
import java.util.Scanner;

public class ServerLauncher {

    private static final int SERVER_PORT = 8080;

    public static void main(String[] args) throws IOException {
        main.java.ProxyServer server = new main.java.ProxyServer(SERVER_PORT);
        server.start();

        // Uncomment the following line to run a sample API.
        // test();

        System.out.println("Server running, press Enter to kill.");
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();
        server.stopServer();
    }

    private static void test() throws IOException {
        Client client = new Client();
        client.connect("127.0.0.1", SERVER_PORT);
        String response = client.post("http://api.giphy.com/v1/gifs/search?q=ryan+gosling&api_key=dc6zaTOxFJmzC&limit=5");
        System.out.println(response);
        client.stopConnection();
    }
}
