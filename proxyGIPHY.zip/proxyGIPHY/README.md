#Oscar Courchaine - 11/16/20 - Server Take-Home Exercise

###Usage Instructions:
Setup: Unzip the .zip file. There will be 3 Java classes and this README.md.

Compile: from src directory run: 

`mvn package`

Run: from same directory run:

`java -cp target/GIPHYproxy-1.0-jar-with-dependencies.jar main.java.ServerLauncher`


Usage: 

Once the server is running, it will stay running until any input is entered.
To run the included test, uncomment the line 'test()' in ServerLauncher.main()

