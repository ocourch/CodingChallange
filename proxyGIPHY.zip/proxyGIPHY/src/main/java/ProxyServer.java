package main.java;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;

import org.apache.commons.io.IOUtils;

public class ProxyServer extends Thread {
    private final int port;

    private HttpURLConnection giphy;
    private ServerSocket serverSocket;
    private Socket clientSocket;
    private PrintWriter printWriter;
    private BufferedReader bufferedReader;

    private static final int GIPHY_API_TIMEOUT = 10000;
    private static final String GIPHY_API_ENCODING = "UTF-8";

    public ProxyServer(int port) {
        this.port = port;
    }

    @Override
    public void run() {
        try {
            serverSocket = new ServerSocket(port);
            clientSocket = serverSocket.accept();
            printWriter = new PrintWriter(clientSocket.getOutputStream(), true);
            bufferedReader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            String input = bufferedReader.readLine();
            URL url = new URL(input);
            giphy = (HttpURLConnection) url.openConnection();

            giphy.setConnectTimeout(GIPHY_API_TIMEOUT);
            giphy.setReadTimeout(GIPHY_API_TIMEOUT);

            // All giphy requests should be GET
            giphy.setRequestMethod("GET");
            giphy.connect();


            if (giphy.getResponseCode() != 200) {
                for (String key : giphy.getHeaderFields().keySet()) {
                    System.out.println(key + " " + giphy.getHeaderFields().get(key).get(0));
                }
                throw new IOException("Bad response! Code: " + giphy.getResponseCode());
            }

            String body;
            InputStream inputStream = null;

            try {
                inputStream = giphy.getInputStream();

                String encoding = giphy.getContentEncoding();
                encoding = encoding == null ? GIPHY_API_ENCODING : encoding;

                body = IOUtils.toString(inputStream, encoding);
            } catch (IOException e) {
                throw new IOException(e);
            } finally {
                if (inputStream != null) {
                    inputStream.close();
                }
            }

            if (body == null) {
                throw new IOException("Received null response from GIPHY.");
            }

            printWriter.println(body);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void stopServer() throws IOException {
        bufferedReader.close();
        printWriter.close();
        clientSocket.close();
        serverSocket.close();
    }


}
