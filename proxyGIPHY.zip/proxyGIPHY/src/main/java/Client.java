package main.java;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 * Basic client for testing purposes.
 */
public class Client {

    private Socket socket;
    private PrintWriter printWriter;
    private BufferedReader bufferedReader;

    public void connect(String address, int port) throws IOException {
        socket = new Socket(address, port);
        printWriter = new PrintWriter(socket.getOutputStream(), true);
        bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
    }

    public String post(String msg) throws IOException {
        printWriter.println(msg);
        return bufferedReader.readLine();
    }

    public void stopConnection() throws IOException {
        bufferedReader.close();
        printWriter.close();
        socket.close();
    }

}
